"use strict";

process.on('SIGINT', function () {
  process.exit();
});
