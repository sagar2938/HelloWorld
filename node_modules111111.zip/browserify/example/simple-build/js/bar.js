exports.coeff = function (x) {
    return Math.log(x) / Math.log(2) + 1;
};
