module.exports = function () {
    throw 'beep';
};
