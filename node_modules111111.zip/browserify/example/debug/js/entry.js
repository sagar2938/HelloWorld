var thrower = require('./thrower');
thrower();
