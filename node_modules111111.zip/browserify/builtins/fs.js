// nothing to see here... no file methods for the browser
