ex(require('./beep.json'));
