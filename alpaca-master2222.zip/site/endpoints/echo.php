<?php

print('<pre>');
print_r($_POST);
print('</pre>');

?>