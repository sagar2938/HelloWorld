require.define($__filename,Function(['require','module','exports','__dirname','__filename','process'],$body
));
require($__filename);
