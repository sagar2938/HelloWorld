require.modules[$__filename] = function () {
    return $body;
};
