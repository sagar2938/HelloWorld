require.define($__filename,function(require,module,exports,__dirname,__filename,process){$body
});
