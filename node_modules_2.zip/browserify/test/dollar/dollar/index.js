// foo $ bar $ baz

var $ = function (x) {
    return x * 100;
};

module.exports = $;
