times ++;
t.equal(times, 3);
t.end();
