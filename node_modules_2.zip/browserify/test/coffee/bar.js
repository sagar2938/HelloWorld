module.exports = require('./foo.coffee')(50);
