
module.exports = function(buffer) {
  return buffer instanceof Uint8Array;
}
