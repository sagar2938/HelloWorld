module.exports = function(size) {
  return new Uint8Array(size)
}
