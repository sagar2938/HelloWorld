<?php
    $json = stripslashes($_POST["json"]);
    echo $json;
?>