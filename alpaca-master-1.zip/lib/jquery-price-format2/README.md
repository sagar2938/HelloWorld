Jquery-Price-Format
===================

jQuery Price Format Plugin is a plugin to format input text fields as prices. 
For example, if you type 123456, the plugin updates it to US$ 1,234.56. 
It is costumizable, so you can use other prefixes and separators (for example, use it to get R$ 1.234,55), use plus sign and minus sign.

Now in the version 2.0, jQuery Price Format can be used for any HTML element.

Check our site for examples: http://jquerypriceformat.com