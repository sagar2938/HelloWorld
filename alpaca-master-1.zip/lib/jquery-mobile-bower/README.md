jquery-mobile-bower
=================

A ready to use version of jquery mobile


If you want to use [jQuery Mobile](http://jquerymobile.com/) via [Bower](http://bower.io) this is the easiest way.
