var helloWorld;

hellowWorld = (function(){
  return function(){
    return 'Hello World!';
  };
})();