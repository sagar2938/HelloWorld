
0.0.23 / 2014-09-02
==================

 * Merge pull request #27 from zjjw/create_only

0.0.22 / 2014-08-08
==================

 * Handling S3 - 307 Status code pull request #30 from smalltownheroes/master

0.0.21 / 2014-08-06
==================

 * add simulate option

0.0.20 / 2014-07-18
==================

 * dont use file.clone when gzip file to conserve file custom ppties

0.0.19 / 2014-07-15
==================

 * Fixes #22
 * Merge pull request #24 from koistya/master
 * Merge pull request #25 from scalableminds/master
 * added concurrent upload sample
 * Fix relative paths on Windows. Fixes pgherveou/gulp-awspublish#20

0.0.18 / 2014-07-08
==================

 * add s3.date property

0.0.17 / 2014-06-16
==================

 * add user with no upload rights test
 * update error reporting

0.0.16 / 2014-05-08
==================

 * fixes #14, add force option on publish to bypass skip/cache

0.0.15 / 2014-05-08
==================

 * force end event fixes #13
 * add test and doc for sync prefix option

0.0.14 / 2014-04-22
==================

 * Fixes #45

0.0.11 / 2014-02-14
==================

 * Merge window fix, pull request #3 from jonathandelgado/patch-1

0.0.10 / 2014-02-14
==================

 * update doc
 * add ext option on gzip plugin

0.0.9 / 2014-02-14
==================

 * fix missing dep

0.0.8 / 2014-02-06
==================

 * fix cache plugin bug - too many save

0.0.7 / 2014-02-06
==================

 * sync refactoring
 * add options to filter files on the log reporter

0.0.6 / 2014-02-05
==================

 * remove first / from s3 path

0.0.5 / 2014-02-05
==================

 * update sync

0.0.4 / 2014-02-04
==================

 * update cache method

0.0.2 / 2014-02-04
==================

 * fix gz upload
 * update logging padding
 * add cache feature

0.0.1 / 2014-02-03
==================

 * first commit

