require("coffee-script/register");
require("./tests.coffee");
