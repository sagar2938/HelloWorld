# grunt-legacy-log
> The Grunt 0.4.x logger.

[![Build Status](https://secure.travis-ci.org/gruntjs/grunt-legacy-log.png?branch=master)](http://travis-ci.org/gruntjs/grunt-legacy-log)
[![Built with Grunt](https://cdn.gruntjs.com/builtwith.png)](http://gruntjs.com/)

