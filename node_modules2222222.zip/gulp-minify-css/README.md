# Deprecation warning
This package has been deprecated. Please use [`gulp-clean-css`](https://github.com/scniro/gulp-clean-css) instead.

## LICENSE
MIT © 2016
