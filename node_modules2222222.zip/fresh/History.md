
0.2.1 / 2014-01-29
==================

 * fix: support max-age=0 for end-to-end revalidation

0.2.0 / 2013-08-11
==================

  * fix: return false for no-cache
