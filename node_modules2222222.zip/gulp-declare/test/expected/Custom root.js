global["App"] = global["App"] || {};
global["App"]["Templates"] = global["App"]["Templates"] || {};
global["App"]["Templates"]["Main"] = function() { return "Main"; };