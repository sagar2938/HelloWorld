this["Namespace"] = this["Namespace"] || {};
this["Namespace"]["App"] = this["Namespace"]["App"] || {};
this["Namespace"]["App"]["Main"] = function() { return "Main"; };
this["Namespace"]["App"]["Header"] = function() { return "Header"; };
this["Namespace"]["App"]["Footer"] = function() { return "Footer"; };