this["App"] = this["App"] || {};
this["App"]["Main"] = function() { return "Main"; };