this["MyApp"] = this["MyApp"] || {};
this["MyApp"]["Templates"] = this["MyApp"]["Templates"] || {};
this["MyApp"]["Templates"]["App"] = this["MyApp"]["Templates"]["App"] || {};
this["MyApp"]["Templates"]["App"]["Main"] = function() { return "App"; };