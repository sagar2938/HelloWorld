var pkg = require("../package");
console.log(pkg.version);