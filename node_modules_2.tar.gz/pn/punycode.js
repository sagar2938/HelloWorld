var punycode = require("punycode");
module.exports = punycode;