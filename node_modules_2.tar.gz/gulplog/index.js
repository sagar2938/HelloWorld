'use strict';

var getLogger = require('glogg');

var logger = getLogger('gulplog');

module.exports = logger;
