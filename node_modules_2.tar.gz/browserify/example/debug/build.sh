#!/bin/bash

browserify js/entry.js -v -o browserify.js --debug
