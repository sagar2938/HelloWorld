
1.0.0 / 2013-12-11
==================

 * add repository to package.json
 * add MIT license

0.0.4 / 2012-06-17 
==================

  * changed: ret -1 for unsatisfiable and -2 when invalid

0.0.3 / 2012-06-17 
==================

  * fix last-byte-pos default to len - 1

0.0.2 / 2012-06-14 
==================

  * add `.type`
