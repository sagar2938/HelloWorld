global["MyApp"] = global["MyApp"] || {};
global["MyApp"]["Templates"] = global["MyApp"]["Templates"] || {};
global["MyApp"]["Templates"]["Final"] = global["MyApp"]["Templates"]["Final"] || {};