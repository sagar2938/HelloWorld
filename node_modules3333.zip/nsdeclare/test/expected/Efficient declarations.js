this["MyApp"] = this["MyApp"] || {};
this["MyApp"]["Templates"] = this["MyApp"]["Templates"] || {};
this["MyApp"]["Templates"]["One"] = this["MyApp"]["Templates"]["One"] || {};
this["MyApp"]["Templates"]["Two"] = this["MyApp"]["Templates"]["Two"] || {};
this["MyApp"]["Templates"]["Two"]["One"] = this["MyApp"]["Templates"]["Two"]["One"] || {};
this["MyApp"]["Templates"]["Two"]["Two"] = this["MyApp"]["Templates"]["Two"]["Two"] || {};