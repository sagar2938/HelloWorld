var tty = require("tty");
module.exports = tty;