// Get in there before browserify

var core_require = require;

