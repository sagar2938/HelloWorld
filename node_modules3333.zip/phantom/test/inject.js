//This isn't really a very good test
//(function(){var foo = 3;})();
