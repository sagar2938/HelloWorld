# Gherkin.js

This is a pure JavaScript gherkin lexer/parser.
