Before do
  @aruba_timeout_seconds = 30
end
